﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRacingGame
{
    public partial class Form1 : Form
    {
        //global variables
        int carSpeed = 5;
        int roadSpeed = 5;
        bool carLeft;
        bool carRight;
        int trafficSpeed = 5;
        int Score = 0;
        Random rnd = new Random();

        private void Reset()
        {
            trophy.Visible = false; //hide the trophy image
            button1.Enabled = false; //Disable the button when game is running
            explosion.Visible = false; //Hide the explosion image
            trafficSpeed = 5; //Set default traffic speed
            roadSpeed = 5; //Set the road speed back to default

            Score = 0; //Reset score to 0

            player.Left = 161; //Reset player left
            player.Top = 286; //Reset player top

            carLeft = false;  //Reset moving left to false
            carRight = false; //Reset moving right to false

            //Move the AI to default position this will be off the screen
            AI1.Left = 66;
            AI1.Top = -120;

            AI2.Left = 294;
            AI2.Top = -185;

            //Reset the road to their default position
            roadTrack2.Left = -3;
            roadTrack2.Top = -222;
            roadTrack1.Left = -2;
            roadTrack1.Top = -638;

            //Start the timer
            timer1.Start();
        }

        public Form1()
        {
            InitializeComponent();
            Reset();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Score++; //increase the score as we move

            distance.Text = "" + Score; //show the score on the distance label

            roadTrack1.Top += roadSpeed; //Move the track 1 down with the +=
            roadTrack2.Top += roadSpeed; //Move the track 2 down with the +=


            //If the track has gone past -630 then we set it back to default
            //this means it will give us a seamless animation

            if(roadTrack1.Top > 630)
            {
                roadTrack1.Top = -630;

            }
            if(roadTrack2.Top > 630)
            {
                roadTrack2.Top = -630;
            }
            //end of track animation

            if(carLeft) { player.Left -= carSpeed; } //move the car left if the car left is true
            if(carRight) { player.Left += carSpeed; } //Move the car right if the car right is true

            //end of car moving

            //bounce the car off boundaries of the panel
            if(player.Left < 1)
            {

                carLeft = false; //stop the car from going off screen

            }
            else if(player.Left + player.Width > 380)
            {
                carRight = false;

            }


            //move thet AI cars down
            AI1.Top += trafficSpeed;
            AI2.Top += trafficSpeed;

            //respawn the AIs and change their images
            if(AI1.Top > panel1.Height)
            {
                changeAI1(); //Change the AI car images once they left the scene
                AI1.Left = rnd.Next(2, 160); //Random numbers where they appear on the Left
                AI1.Top = rnd.Next(100, 200) * -1; //Random numbers where they appear on top

            }
            if(AI2.Top > panel1.Height)
            {
                changeAI2();
                AI2.Left = rnd.Next(185, 327); //Random numbers where they appear on the left
                AI2.Top = rnd.Next(100, 200) * -1; //Random numbers where they appear on top

            }
            //end of respawning the AIs and image changing

            //hit test the player and AI
            //if statement is checking multiple conditions
            //if player hits AI1 or player hits AI2
            if(player.Bounds.IntersectsWith(AI1.Bounds) || player.Bounds.IntersectsWith(AI2.Bounds))
            {
                gameOver(); //this will run when the player hits an AI object


            }
            //end of hit testing player

            //speed up the traffic
            //Checking for multiple conditions
            //If Score is above 100 AND below 500
            if (Score > 100 && Score < 500)
            {
                trafficSpeed = 6;
                roadSpeed = 7;

            }
            //if score is above 500 AND below 1000
            else if (Score > 500 && Score < 1000)
            {
                trafficSpeed = 7;
                roadSpeed = 8;

            }
            //if score is above 1200
            else if (Score > 1200)
            {
                trafficSpeed = 9;
                roadSpeed = 10;
            }
            //end of traffic speeding up

        }

        private void moveCar(object sender, KeyEventArgs e)
        {
            //if pressed the lft key AND the player is inside the panel
            if(e.KeyCode == Keys.Left && player.Left > 0)
            {
                carLeft = true;
            }
            //if player pressed the right key and the player left plus player width is less then the panel1 width
            //then we set player right to true
            if(e.KeyCode == Keys.Right && player.Left + player.Width < panel1.Width)
            {
                carRight = true;
            }
        }

        private void stopCar(object sender, KeyEventArgs e)
        {
            //if the LEFT key is up we set the car left to false
            if(e.KeyCode == Keys.Left)
            {
                carLeft = false;
            }
            //if the RIGHT key is up we set the car right to false;
            if(e.KeyCode == Keys.Right)
            {
                carRight = false;
            }
        }

        private void changeAI1()
        {
            int num = rnd.Next(1, 8);

            switch (num)
            {
                //if the number generated is 1 we show the green car
                case 1:
                    AI1.Image = Properties.Resources.carGreen;
                    break;
                case 2:
                    AI1.Image = Properties.Resources.carGrey;
                    break;
                case 3:
                    AI1.Image = Properties.Resources.carPink;
                    break;
                case 4:
                    AI1.Image = Properties.Resources.carOrange;
                    break;
                case 5:
                    AI1.Image = Properties.Resources.carPink;
                    break;
                case 6:
                    AI1.Image = Properties.Resources.CarRed;
                    break;
                case 7:
                    AI1.Image = Properties.Resources.TruckBlue;
                    break;
                case 8:
                    AI1.Image = Properties.Resources.TruckWhite;
                    break;
                default:
                    break;

            }
        } //end of changeAI1

        private void changeAI2()
        {
            int num = rnd.Next(1, 8);

            switch (num)
            {
                case 1:
                    AI2.Image = Properties.Resources.carGreen;
                    break;
                case 2:
                    AI2.Image = Properties.Resources.carGrey;
                    break;
                case 3:
                    AI2.Image = Properties.Resources.carPink;
                    break;
                case 4:
                    AI2.Image = Properties.Resources.carOrange;
                    break;
                case 5:
                    AI2.Image = Properties.Resources.carPink;
                    break;
                case 6:
                    AI2.Image = Properties.Resources.CarRed;
                    break;
                case 7:
                    AI2.Image = Properties.Resources.TruckBlue;
                    break;
                case 8:
                    AI2.Image = Properties.Resources.TruckWhite;
                    break;
                default:
                    break;
            }
        }//end of change AI2

        private void gameOver()
        {
            trophy.Visible = true;

            timer1.Stop();

            button1.Enabled = true;

            //showing the explosion image on top of the car image
            explosion.Visible = true;
            player.Controls.Add(explosion);
            explosion.Location = new Point(-8, 5);
            explosion.BackColor = Color.Transparent;
            explosion.BringToFront();
            
            //if thte player scoree less than a 100 we give them a bronze
            if(Score < 1000)
            {
                trophy.Image = Properties.Resources.bronze;

            }
            //If player scored more than 2000 then give them a silver star
            if(Score > 2000)
            {
                trophy.Image = Properties.Resources.silver;

            }
            //if player Scored more than 3500 then give them a gold trophy
            if(Score > 3500)
            {
                trophy.Image = Properties.Resources.gold;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Reset();
        }
    }//end of partial class Form
}//end of namespace
