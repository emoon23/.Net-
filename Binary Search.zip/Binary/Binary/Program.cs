﻿/**
 * 
 *  Create the program which you the user to will have to
 *  use binary search on a List that you will create
 * 
 * */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Binary
{
    class BSearch
    {


        static void Main(string[] args)
        {
            //Create a list with names of your friends
            List<String> names = new List<string>();
            names.Add("Edward");
            names.Add("David");
            names.Add("Sam");
            names.Add("Chris");
            names.Add("Dennis");
            names.Add("Jerome");
            names.Add("Vince");
            names.Add("Jake");
            names.Add("Mike");
            names.Add("Leo");
            names.Add("Brian");

            /*
                        //Print out the List
                        Console.WriteLine(names[0]);
                        Console.WriteLine(names[1]);
                        Console.WriteLine(names[2]);
                        Console.WriteLine(names[3]);
                        Console.WriteLine(names[4]);
                        Console.WriteLine(names[5]);
                        Console.WriteLine(names[6]);
                        Console.WriteLine(names[7]);
                        Console.WriteLine(names[8]);
                        Console.WriteLine(names[9]);
                        Console.WriteLine(names[10]);

                  */

            Console.WriteLine();
            foreach(string name in names)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("\nSort");
            Console.WriteLine("========");
            names.Sort();

            Console.WriteLine();
            foreach(string name in names)
            {
                Console.WriteLine(name);

            }
            Console.WriteLine("\nBinarySearch and Insert \"Phil\":");
            Console.WriteLine("====================================");
            int index = names.BinarySearch("Phil");
            if(index < 0)
            {
                names.Insert(~index, "Phil");
            }

            Console.WriteLine();
            foreach(string name in names)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("\nBinarySearch and Insert \"Kevin\":");
            Console.WriteLine("====================================");
            index = names.BinarySearch("Kevin");
            if(index < 0)
            {
                names.Insert(~index, "Kevin");

            }
            Console.WriteLine();
            foreach(string name in names)
            {
                Console.WriteLine(name);
            }
        }
    }
}
