﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Day2Operators
{ 
    class Program
    {
        static void solve(double meal_cost, int tip_percent, int tax_percent)
        {

            //First Converting to Decimal Values

            Decimal meals = Convert.ToDecimal(meal_cost);
            Decimal percent = 100.0m;
            Decimal tip = Convert.ToDecimal(tip_percent);
            Decimal tax = Convert.ToDecimal(tax_percent);

            //Getting the decimal values after conversion
            tip = meals / percent; //should be .12
            tax = tax / percent; //should be .8

            //convert to double 
            double tips = (double)tip;
            double tp = tip_percent;
            double tx = (double)tax;
            double txx = tx * meal_cost;

            //multiply the tip_percent to the conversion
            tp = tips * tp;

            //Total Cost
            //     total_cost = 12.00 + 2.4 + .96
            double total_cost = meal_cost + tp + txx;

           
            //Console.WriteLine((total_cost));
             //Total Cost after rounding
            Console.WriteLine(Math.Round(total_cost));


            //Testing purposes only
            /*
            Console.WriteLine("MEAL COST: " + meal_cost.ToString("N"));
            Console.WriteLine("TIP PERCENT: " + tip);
            Console.WriteLine("MEAL AFTER TIP: " + tp);
            Console.WriteLine("TAX: PERCENT: " + tax);
            Console.WriteLine("TAX AFTER TIP: " + txx.ToString("N"));
            Console.WriteLine("TOTAL COST: " + total_cost);
            Console.WriteLine("ROUNDED VALUE: " + Math.Round(total_cost));
             */

        }


        static void Main(string[] args)
        {
            Program pgm = new Program();
           
            double meal_cost = Convert.ToDouble(Console.ReadLine());

            int tip_percent = Convert.ToInt32(Console.ReadLine());

            int tax_percent = Convert.ToInt32(Console.ReadLine());
           
            solve(meal_cost, tip_percent, tax_percent);

          
            Console.ReadKey();
        }
    }
}
